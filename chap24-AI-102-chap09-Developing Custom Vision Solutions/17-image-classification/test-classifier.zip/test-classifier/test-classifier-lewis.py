from azure.cognitiveservices.vision.customvision.prediction import CustomVisionPredictionClient
from msrest.authentication import ApiKeyCredentials
import os

def main():
    #from dotenv import load_dotenv

    try:
        # Get Configuration Settings
        #load_dotenv()
        prediction_endpoint = 'https://azcv1688-prediction.cognitiveservices.azure.com/' #os.getenv('PredictionEndpoint')
        prediction_key = 'b2981fffdf3a41a989d22823d5f7590d' #os.getenv('PredictionKey')
        project_id = '3e61f72e-dcb2-41f4-8c7d-3380b9387b87' #os.getenv('ProjectID')
        model_name = 'fruit-classifier' #os.getenv('ModelName')

        # Authenticate a client for the training API
        credentials = ApiKeyCredentials(in_headers={"Prediction-key": prediction_key})
        prediction_client = CustomVisionPredictionClient(endpoint=prediction_endpoint, credentials=credentials)

        # Classify test images
        for image in os.listdir('test-images'):        
            print(os.path.join('test-images',image))
            image_data = open(os.path.join('test-images',image), "rb").read()
            results = prediction_client.classify_image(project_id, model_name, image_data)

            # Loop over each label prediction and print any with probability > 50%
            for prediction in results.predictions:
                if prediction.probability > 0.5:
                    print(image, ': {} ({:.0%})'.format(prediction.tag_name, prediction.probability))
    except Exception as ex:
        print(ex)

if __name__ == "__main__":
    main()

